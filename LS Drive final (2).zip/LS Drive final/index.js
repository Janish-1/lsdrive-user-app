document.getElementById("openPopupButton").addEventListener("click", function() {
  document.getElementById("popupContainer").style.display = "block";
});

// Function to close the popup
function closePopup() {
  document.getElementById("popupContainer").style.display = "none";
}
